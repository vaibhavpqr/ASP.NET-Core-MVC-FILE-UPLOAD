﻿using Microsoft.EntityFrameworkCore;

namespace WebApplication58.Models
{
    public class ManagerContext : DbContext
    {
        public ManagerContext(DbContextOptions options):base(options) { }

        public DbSet<Manager> managers { get; set; } 
    }
}
