﻿using System.ComponentModel.DataAnnotations;

namespace WebApplication58.Models
{
    public class ManagerDummy
    {
        [Key]
        public int mid { get; set; }
        public String mname { get; set; }

        public String memail { get; set; }
        public IFormFile photo { get; set; }
    }
}
