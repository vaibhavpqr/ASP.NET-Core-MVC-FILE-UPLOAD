﻿using System.ComponentModel.DataAnnotations;

namespace WebApplication58.Models
{
    public class Manager
    {
        [Key]
        public int mid { get;set; }
        public String mname { get; set; }

        public String memail { get; set; }
        public String photo { get; set; }
    }
}
