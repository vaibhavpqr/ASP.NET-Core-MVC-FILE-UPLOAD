﻿using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using WebApplication58.Models;

namespace WebApplication58.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        IWebHostEnvironment env;
        ManagerContext mc;

        public HomeController(ILogger<HomeController> logger, IWebHostEnvironment env, ManagerContext mc)
        {
            _logger = logger;
            this.env = env;
            this.mc = mc;
        }
        public IActionResult Display()
        {
           
            return View(mc.managers.ToList());
        }

        public IActionResult Index()
        {
            return View();
        }
        [HttpGet]
        public IActionResult Create()
        {
             return View();
        }
        [HttpPost]
        public IActionResult Create(ManagerDummy m1)
        {

            String folder=Path.Combine(env.WebRootPath, "images");
            String filename = m1.photo.FileName;
            String filepath=Path.Combine(folder, filename);
            m1.photo.CopyTo(new FileStream(filepath, FileMode.Create));
            Manager mg = new Manager();
            mg.mid=m1.mid;
            mg.memail = m1.memail;
            mg.mname = m1.mname;
            mg.photo = filename;
            mc.managers.Add(mg);
            mc.SaveChanges();

                return RedirectToAction("Index");
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
